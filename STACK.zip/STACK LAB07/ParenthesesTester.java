import java.util.Scanner;
public class ParenthesesTester
{
  public static void main(String [] args)
  {
    Scanner key=new Scanner(System.in);
    ArrayStack s1=new ArrayStack ();
    ArrayStack s2=new ArrayStack();
    System.out.println("Please enter an expression");
    String s=key.nextLine();
    char [] c=s.toCharArray();
    try{
      for(int i=0;i<c.length;i++)
      {
        if(c[i]=='(' || c[i]=='{' || c[i]=='[')
        {
          s1.push(c[i]);
          s2.push(i);
        }
        else if(c[i]==')' || c[i]=='}' || c[i]==']')
        {
          char ch=(Character)s1.pop();
          int a=(Integer)s2.pop();
          if(ch=='(' && c[i]==')' || ch=='{' && c[i]=='}' || ch=='[' && ch==']')
          {
            System.out.println("The expression is correct");
          }
          else
          {
            System.out.println("Error at character number"+" "+ a);
            break;                     
                                 
                                 
          }
          
          
        }
      }
    }   
    catch(Exception e){
      System.out.println("The exception is"+ " "+e);
    }
    
    
  }
}