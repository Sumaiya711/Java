public class StackOverflowException extends Exception{

}