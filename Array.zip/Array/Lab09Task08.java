import java.util.Scanner;
public class Lab09Task08
{
  public static void main(String[]args)
  {
    Scanner key=new Scanner(System.in);
    String[]array={"zero","one","two","three","four","five","six","seven","eight","nine"};
    System.out.println("Please enter a number");
    int num=key.nextInt();
    System.out.println(array[num]);
  }
}
                           
    

 
 
    