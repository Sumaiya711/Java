import java.util.Scanner;
public class Lab09Task03
{
  public static void main(String[]args)
  {
    Scanner key=new Scanner(System.in);
    int[]array=new int[5];
    for(int index=0;index<=array.length-1;index++)
    {
      System.out.println("Please enter a number");
      array[index]=key.nextInt();
    }
    int max=array[0],min=array[0],maxPos=0,minPos=0;
    for(int check=0;check<=array.length-1;check++)
    {
      if(array[check]>max)
      {
        max=array[check];
        minPos=check;
      }
      else if(array[check]<min)
      {
        min=array[check];
        minPos=check;
      }
    }
    System.out.println("Smallest number "+min+" was found at "+minPos);
    System.out.println("Largest number "+max+" was found at "+maxPos);
  }
}
    
     