import java.util.Scanner;
public class Lab09Task06
{
  public static void main(String[]args)
  {
    Scanner key=new Scanner(System.in);
    int[]array=new int[5];
    for(int index=0;index<=array.length-1;index++)
    {
      System.out.println("Please enter a number");
      array[index]=key.nextInt();
    }
    int min,pos,temp;
    for(int index=0;index<=array.length-1;index++)
    {
      min=array[index];
      pos=index;
      for(int check=index;check<=array.length-1;check++)
      {
        if(array[check]<min)
        {
          min=array[check];
          pos=check;
        }
      }
      if(min<array[index])
      {
        temp=array[index];
        array[index]=min;
        array[pos]=temp;
      }
    }
    if(array.length%2==1)
    {
      int index=array.length/2;
      int median=array[index];
      System.out.println(median);
    }
    else
    {
      int index1=array.length/2;
      int index2=index1-1;
      double Sum=array[index1]+array[index2];
      double median=Sum/2;
      System.out.println(median);
    }
    
  }
}
