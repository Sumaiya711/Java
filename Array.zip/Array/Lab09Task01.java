import java.util.Scanner;
public class Lab09Task01
{
  public static void main(String[]args)
  {
    Scanner key=new Scanner(System.in);
    int[]array=new int[5];
    for(int index=0;index<=array.length-1;index++)
    {
      System.out.println("Please enter a number");
      array[index]=key.nextInt();
    }
    int max=array[0];
    
    for(int check=0;check<=array.length-1;check++)
    {
      if(array[check]>max)
      {
        max=array[check];
      }
    }
    System.out.println(max);
  }
}

 