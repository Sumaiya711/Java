import java.util.Scanner;
public class Lab09Task07
{
  public static void main(String[]args)
  {
    Scanner key=new Scanner(System.in);
    int[]array=new int[5];
    for(int index=0;index<=array.length-1;index++)
    {
      System.out.println("Please enter a number");
      array[index]=key.nextInt();
    }
    System.out.print(array[0]+",");
    for(int even=1;even<array.length-1;even++)
    {
      if(even%2==0)
      {
        System.out.print(array[even]+",");
      }
    }
    for(int odd=1;odd<array.length-1;odd++)
    {
      if(odd%2==1)
      {
        System.out.print(array[odd]+",");
      }
    }
    int index=9;
    System.out.print(array[index]);
    System.out.println();
  }
}

                     
