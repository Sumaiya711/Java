import java.util.Scanner;
public class Lab09Task04
{
  public static void main(String[]args)
  {
    Scanner key=new Scanner(System.in);
    int[]array=new int[5];
    for(int index=0;index<=array.length-1;index++)
    {
      System.out.println("Please enter a number");
      array[index]=key.nextInt();
    }
    int min,pos,temp;
    for(int index=0;index<=array.length-1;index++)
    {
      min=array[index];
      pos=index;
      for(int check=index;check<=array.length-1;check++)
      {
        if(array[check]<min)
        {
          min=array[check];
          pos=check;
        }
      }
      if(min<array[index])
      {
        temp=array[index];
        array[index]=min;
        array[pos]=temp;
      }
    }
    for(int index=0;index<=array.length-1;index++)
    {
      System.out.print(array[index]+" ");
    }
  }
}
    
        
    