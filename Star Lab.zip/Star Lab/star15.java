import java.util.Scanner;
public class star15
{
  public static void main(String[]args)
  {
    Scanner key=new Scanner(System.in);
    System.out.println("Please enter line number");
    int line=key.nextInt();
    System.out.println("Please enter column number");
    int column=key.nextInt();
    for(int row=1;row<=line;row++)
    {
      for(int columnCount=1;columnCount<=column;columnCount++)
      {
         if(row==1 || row==line || columnCount==1 || columnCount==column)
         {
           System.out.print(columnCount);
         }
         else
         {
           System.out.print(" ");
         }
      }
      System.out.println();
    }
  }
}
           
      