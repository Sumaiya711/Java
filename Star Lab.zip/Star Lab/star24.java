import java.util.Scanner;
public class star24
{
  public static void main(String[]args)
  {
    Scanner key=new Scanner(System.in);
    System.out.println("Please enter a number");
    int N=key.nextInt();
    for(int c1=1;c1<=N;c1++)
    {
      System.out.print(c1);
    }
    for(int c2=N-1;c2>=1;c2--)
    {
      System.out.print(c2);
    }
    System.out.println();
  }
}
    
    
                            
    