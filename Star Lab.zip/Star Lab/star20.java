import java.util.Scanner;
public class star20
{
  public static void main(String[]args)
  {
    Scanner key=new Scanner(System.in);
    System.out.println("Please enter line number");
    int line=key.nextInt();
    for(int row=1;row<=line;row++)
    {
      for(int space=1;space<=line-row;space++)
      {
        System.out.print(" ");
      }
      if(row==1)
      {
        System.out.print("*");
      }
      else if(row==line)
      {
        for(int star=1;star<=2*row-1;star++)
        {
          System.out.print("*");
        }
      }
      else
      {
        System.out.print("*");
        for(int space=1;space<=2*row-3;space++)
        {
          System.out.print(" ");
        }
        System.out.print("*");
      }
      System.out.println();
    }
  }
}
        
      
    
      
        
        
      
      
      