import java.util.Scanner;
public class star18
{
  public static void main(String[]args)
  {
    Scanner key=new Scanner(System.in);
    System.out.println("Please enter line number");
    int line=key.nextInt();
    for(int row=1;row<=line;row++)
    {
      for(int space=1;space<=line-row;space++)
      {
        System.out.print(" ");
      }
      if(row==1 || row==2 || row==line)
      {
        for(int star=1;star<=row;star++)
        {
          System.out.print("*");
        }
      }
      else
      {
        System.out.print("*");
        for(int space=1;space<=row-2;space++)
        {
          System.out.print(" ");
        }
        System.out.print("*");
      }
      System.out.println();
    }
  }
}