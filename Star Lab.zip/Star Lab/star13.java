import java.util.Scanner;
public class star13
{
  public static void main(String[]args)
  {
    Scanner key=new Scanner(System.in);
    System.out.println("Please enter line number");
    int line=key.nextInt();
    for(int row=1;row<=line;row ++)
    {
      for(int space=1;space<=line-row;space++)
      {
        System.out.print(" ");
      }
      for(int count=1;count<=2*row-1;count++)
      {
        System.out.print(count);
      }
      System.out.println();
    }
    for(int row=1;row<=line-1;row++)
    {
      for(int space=1;space<=row;space++)
      {
        System.out.print(" ");
      }
      for(int count=1;count<=2*(line-row)-1;count++)
      {
        System.out.print(count);
      }
      System.out.println();
    }
  }
}
    