import java.util.Scanner;
public class star25
{
    public static void main(String[] args)
    {
        Scanner key = new Scanner(System.in);
        System.out.println("please enter number");
        int line=key.nextInt();
        for (int row=1;row<=line;row++)
        {
            for (int space=1;space<=line-row;space++)
            {
                System.out.print(" ");
            }
            for (int c1=1;c1<=row;c1++)
            {
                System.out.print(c1);
            }
            for (int c2=row-1;c2>=1;c2--)
            {
                System.out.print(c2);
            }
            System.out.println();
        }
    }
}