import java.util.Scanner;
public class star12
{
  public static void main(String[]args)
  {
    Scanner key=new Scanner(System.in);
    System.out.println("Please enter line number");
    int line=key.nextInt();
    for(int row=1;row<=line;row ++)
    {
      for(int space=1;space<=line-row;space++)
      {
        System.out.print(" ");
      }
      for(int star=1;star<=2*row-1;star++)
      {
        System.out.print("*");
      }
      System.out.println();
    }
    for(int row=1;row<=line-1;row++)
    {
      for(int space=1;space<=row;space++)
      {
        System.out.print(" ");
      }
      for(int star=1;star<=2*(line-row)-1;star++)
      {
        System.out.print("*");
      }
      System.out.println();
    }
  }
}
    
     