import java.util.Scanner;
public class star05{
  public static void main(String[]args){
    Scanner key=new Scanner(System.in);
    System.out.println("Please enter a number");
    int line=key.nextInt();
    for(int row=1;row<=line;row++){
      for(int star=1;star<=row;star++){
        System.out.print("*");
      }
      System.out.println();
    }
  }
}