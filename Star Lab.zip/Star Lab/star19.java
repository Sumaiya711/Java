import java.util.Scanner;
public class star19
{
  public static void main(String[]args)
  {
    Scanner key=new Scanner(System.in);
    System.out.println("Please enter line number");
    int line=key.nextInt();
    for(int row=1;row<=line;row++)
    {
      int space;
      for(space=1;space<=line-row;space++)
      {
        System.out.print(" ");
      }
      if(row==1 || row==2 || row==line)
      {
        for(int count=space;count<=line;count++)
        {
          System.out.print(count);
        }
      }
      else
      {
        System.out.print(space);
        for(space=1;space<=row-2;space++)
        {
          System.out.print(" ");
        }
        System.out.print(line);
      }
      System.out.println();
    }
  }
}