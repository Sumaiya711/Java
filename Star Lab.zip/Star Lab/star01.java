import java.util.Scanner;
public class star01{
  public static void main(String[]args){
    Scanner key=new Scanner(System.in);
    System.out.println("Please enter a number");
    int num=key.nextInt();
    for(int count=1;count<=num;count++){
      System.out.print(count);
    }
    System.out.println();
  }
}
     
 
    